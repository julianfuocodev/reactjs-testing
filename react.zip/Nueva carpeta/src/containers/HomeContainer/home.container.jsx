//Imports
import React from "react";
import { ItemList } from "../../components/ItemList/itemlist.component";


//Componente
export const Home = () => {


  //Imprime ItemList
  return (<ItemList />);
};
