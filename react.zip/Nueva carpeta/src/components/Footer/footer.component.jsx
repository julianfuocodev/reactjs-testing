//imports
import React from "react";
import "./footer.component.css"

//componente
export const Footer = () => {


//imprime
    return(
    <p className="footer">De Julian Fuoco para CoderHouse 2020 - By-nos</p>
    )
};
