//Imports
import React from "react";
import "./loading.component.css";


//Componente
export const Loading = () => {

//Imprime Loading  
  return (
    <div className="loading-container">
<h3>Cargando Productos</h3>
    </div>
  );
};
